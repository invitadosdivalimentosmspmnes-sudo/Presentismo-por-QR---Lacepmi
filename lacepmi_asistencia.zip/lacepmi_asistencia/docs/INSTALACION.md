# LACEPMI — Presentismo QR
### Instrucciones de instalación y puesta en marcha

Sistema interno de registro de asistencia y actividades del personal del Laboratorio de Calidad de
Alimentos, Agua y Laboratorio (LACEPMI), mediante código QR. Sin login, sin contraseñas.

---

## 1. Crear el Google Sheet

1. Andá a [sheets.google.com](https://sheets.google.com) y creá una planilla nueva.
2. Ponele un nombre, por ejemplo: `LACEPMI - Base de datos Presentismo`.
3. No hace falta crear las pestañas a mano: el script de instalación las crea solo.

## 2. Cargar el backend (Google Apps Script)

1. En la planilla, andá a **Extensiones > Apps Script**.
2. Borrá todo el contenido del archivo `Código.gs` que aparece por defecto.
3. Pegá el contenido completo del archivo `google-apps-script/Code.gs` de este proyecto.
4. Guardá el proyecto (ícono de disquete o `Ctrl+S`).

## 3. Ejecutar el setup inicial

1. En la barra superior del editor de Apps Script, elegí la función **`setup`** en el
   desplegable de funciones (al lado del botón ▶ Ejecutar).
2. Hacé clic en **Ejecutar**.
3. La primera vez, Google va a pedir autorización: hacé clic en **Revisar permisos**,
   elegí tu cuenta y confirmá (puede aparecer una advertencia de "app no verificada";
   es normal para scripts propios — hacé clic en "Ir a (nombre del proyecto), no seguro" y luego "Permitir").
4. Al terminar, en el panel de "Ejecución" debería verse el mensaje:
   `Setup completo: 20 empleados cargados.`
5. Volvé a la planilla: ahora deberían existir 4 pestañas: `EMPLEADOS`, `INVITADOS`,
   `REGISTROS` y `CONFIGURACIÓN`, con la nómina real ya cargada en `EMPLEADOS`.

## 4. Publicar la API (implementación como aplicación web)

1. En el editor de Apps Script, hacé clic en **Implementar > Nueva implementación**.
2. En "Seleccionar tipo", elegí el ícono de engranaje y luego **Aplicación web**.
3. Configurá:
   - **Descripción**: `API LACEPMI v1`
   - **Ejecutar como**: `Yo (tu cuenta)`
   - **Quién tiene acceso**: `Cualquier usuario`
4. Hacé clic en **Implementar**.
5. Copiá la **URL de la aplicación web** que te da Google (termina en `/exec`).

> Cada vez que modifiques el código del backend, tenés que crear una **nueva versión** desde
> "Implementar > Administrar implementaciones > editar (ícono de lápiz) > Nueva versión > Implementar",
> para que los cambios se reflejen en la URL publicada.

## 5. Configurar el frontend

1. Abrí el archivo `js/config.js` del proyecto.
2. Reemplazá el valor de `APPS_SCRIPT_URL` por la URL que copiaste en el paso anterior:

```js
const CONFIG = {
  APPS_SCRIPT_URL: 'https://script.google.com/macros/s/XXXXXXXXXXXXX/exec',
  ...
};
```

3. Guardá el archivo.

## 6. Publicar / abrir el frontend

Tenés dos opciones:

- **Uso local o en un servidor interno**: subí toda la carpeta `lacepmi-asistencia/` a cualquier
  hosting estático (servidor interno del laboratorio, GitHub Pages, Netlify, etc.) y abrí `index.html`.
- **Prueba rápida**: abrí `index.html` con un servidor local (por ejemplo `python3 -m http.server`
  desde la carpeta del proyecto) y entrá a `http://localhost:8000`. Abrir el archivo directamente
  con doble clic (protocolo `file://`) puede bloquear el acceso a la cámara en algunos navegadores;
  se recomienda siempre servirlo por `http://` o `https://`.

> El lector de cámara requiere una conexión segura (`https://`) en la mayoría de los navegadores
> móviles, salvo en `localhost`. Para uso en producción, publicá el sitio con HTTPS.

## 7. Generar los QR de los empleados

Los QR de los 20 empleados de la nómina ya están asociados automáticamente
(`LACEPMI-EMP-001` a `LACEPMI-EMP-020`) desde el paso de `setup`. Para verlos, descargarlos
e imprimirlos:

1. Entrá a la sección **Códigos QR** de la app.
2. Filtrá por "Empleados" si querés ver solo esa lista.
3. Usá **Descargar** o **Imprimir** en cada tarjeta, o **Descargar todos** / **Imprimir todos**
   para hacerlo en lote.

## 8. Registrar invitados

1. Entrá a la sección **Invitados**.
2. Hacé clic en **Registrar invitado** y completá apellido, nombres y DNI (los demás campos son opcionales).
3. Al guardar, se genera automáticamente su QR (`LACEPMI-INV-001`, `LACEPMI-INV-002`, ...),
   que podés descargar en el momento o más tarde desde la sección Códigos QR.

## 9. Probar el sistema

Ver la checklist completa en `docs/PRUEBAS.md`. Como mínimo, verificá:

- Escanear el QR de un empleado real y registrar "Presente".
- Registrar un invitado nuevo y escanear su QR generado.
- Revisar que el registro aparezca en la pestaña `REGISTROS` de la planilla.
- Revisar que las **Estadísticas** y el **historial individual** reflejen ese registro.

---

## Estructura del proyecto

```
lacepmi-asistencia/
├── index.html            Dashboard
├── registrar.html        Escaneo QR + selección de tipo + confirmación
├── empleados.html        Nómina + historial individual
├── invitados.html        Alta de invitados + historial
├── registros.html        Tabla filtrable + exportación CSV/Excel
├── estadisticas.html     Panel con datos reales y gráficos
├── qr.html               Visualización, descarga e impresión de QR
├── css/
│   ├── styles.css
│   └── responsive.css
├── js/
│   ├── config.js         ⚠️ Acá va la URL de tu Apps Script
│   ├── api.js
│   ├── app.js
│   └── qr.js
├── assets/
│   ├── logo-misiones.jpg
│   └── banner-lacepmi.jpg
├── google-apps-script/
│   └── Code.gs            Backend completo (pegar en Apps Script)
└── docs/
    ├── INSTALACION.md
    └── PRUEBAS.md
```

## Notas de privacidad

El DNI se trata como dato sensible: en las vistas generales se muestra parcialmente
enmascarado (por ejemplo `12.****01`) y el contenido del QR nunca incluye el DNI en texto
plano — solo el ID interno (`LACEPMI-EMP-XXX` / `LACEPMI-INV-XXX`).
