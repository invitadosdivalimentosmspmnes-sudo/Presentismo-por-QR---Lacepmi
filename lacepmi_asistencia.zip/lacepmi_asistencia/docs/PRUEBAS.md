# LACEPMI — Checklist de pruebas funcionales

Marcá cada ítem luego de verificarlo con la app ya conectada a Google Sheets.

## Identificación por QR

- [ ] Empleado válido: escanear el QR de un empleado real y confirmar que se identifica correctamente.
- [ ] Invitado válido: registrar un invitado, escanear su QR y confirmar identificación.
- [ ] QR inválido: escanear un QR ajeno a la app y verificar el mensaje "QR no reconocido".
- [ ] Empleado/invitado inexistente: probar con un ID manipulado y verificar el error correspondiente.

## Tipos de registro

- [ ] Presente
- [ ] Ausente
- [ ] Tardanza
- [ ] Auditoría
- [ ] Capacitación
- [ ] Reunión
- [ ] Otro motivo (verificar que pide el campo "Especifique el motivo" y lo guarda en Observación)

## Duplicados

- [ ] Registrar el mismo tipo dos veces seguidas para la misma persona en pocos segundos y verificar
      que aparece el aviso de posible duplicado, con opción de cancelar o registrar igual.

## Cámara

- [ ] Cámara sin permiso: denegar el permiso del navegador y verificar el mensaje de error y el botón "Reintentar".
- [ ] Dispositivo sin cámara (o navegador no compatible): verificar el mensaje correspondiente.

## Conectividad

- [ ] Google Sheets sin conexión: con `APPS_SCRIPT_URL` mal configurada o sin internet, verificar
      que se muestra un error comprensible en vez de fallar en silencio.

## Registros

- [ ] Filtros: probar cada filtro (persona, tipo de persona, tipo de registro, fecha, rango de fechas) por separado y combinados.
- [ ] Búsqueda por nombre.
- [ ] Botones Buscar, Limpiar filtros y Actualizar.
- [ ] Exportación a CSV respetando los filtros aplicados.
- [ ] Exportación a Excel respetando los filtros aplicados.

## Estadísticas

- [ ] Los números de "Registros de hoy" coinciden con los movimientos reales guardados hoy.
- [ ] Los gráficos por tipo, día, persona y actividad mensual reflejan datos reales (sin valores ficticios).

## Historial individual

- [ ] Abrir el historial de un empleado y verificar el resumen por tipo y la tabla de movimientos.
- [ ] Abrir el historial de un invitado y verificar lo mismo.

## Responsive

- [ ] Ver el Dashboard, Registrar y Registros en un celular (o simulador) y confirmar que no hay scroll horizontal.
- [ ] Confirmar que el menú hamburguesa abre y cierra correctamente en pantallas angostas.
- [ ] Probar el lector QR desde un celular real (Android e iPhone).

## Códigos QR

- [ ] Descargar un QR individual.
- [ ] Imprimir un QR individual.
- [ ] Descargar todos los QR.
- [ ] Imprimir todos los QR.

## Creación de invitados

- [ ] Crear un invitado con todos los campos.
- [ ] Crear un invitado solo con los campos obligatorios (apellido, nombres, DNI).
- [ ] Verificar que no se pide ni se crea usuario/contraseña en ningún punto del flujo.
